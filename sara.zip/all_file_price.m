%price setting
%Q
%L


price_base=[800 1000 2000 2000 2000];
price_add=[800 1000 2000 2000 2000];
%linear setting

for q_id=1:5
price_model(q_id,l_id)=price_base(q_id)+(l_id-1)*price_base(l_id);
end


%super linear setting

factor=1.5;

for q_id=1:5
price_model(q_id,l_id)=price_base(q_id)+(l_id-1)^factor*price_base(l_id);
end

%under linear setting

factor=0.5;

for q_id=1:5
price_model(q_id,l_id)=price_base(q_id)+(l_id-1)^factor*price_base(l_id);
end
