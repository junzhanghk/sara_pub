function [price] = get_price(config,price_model)
%config(Q)
%price_model(Q,L);
[Q,L]=size(price_model);

price=0;
for i=1:Q
    price=price+price_model(i,config(i));
end

 
