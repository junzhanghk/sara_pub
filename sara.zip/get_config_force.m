%23-07-2018
%find configuration to fulfill al with minimized cost
function [config,price_final,al_final,find_flag] = get_config_force(t,AL,price_model,tree_node,Alth)

%threat t
%AL at->AL
[n Q L T]=size(t);

T_num=length(tree_node);

T_lv=max([tree_node.lv]);


%find_flag

find_flag=0;

%min_cost
min_cost=1e10;

for i=1:L^Q
   
   current=i;
   for j=1:Q
     part1=mod(current,L);
     part2=(current-part1)/L;
     h(j)=part1+1;
     current=part2;
   end
    
   price=get_price(h,price_model);
   t_al = get_threat_al(h,t,AL);
   [t_al_fin] = get_attack_al(t_al,tree_node);
   
   if(t_al_fin<=Alth)
       find_flag=1;
       if(price<min_cost)
         find_id=i;
         find_h=h;
         min_cost=price;
         find_al=t_al_fin;
       end
   end
end

if(find_flag==1)
config=find_h;
price_final=min_cost;
al_final=find_al;
else
config=zeros(Q,1);
price_final=0;
al_final=0;
end