function [t_al_fin] = get_attack_al(t_al,tree_node)
%t_al: al of threats
%tree_node: all attack tree nodes

T_num=length(tree_node);

T_lv=max([tree_node.lv]);

for i=1:T_lv
    tree_node_list=find([tree_node.lv]==i);
    
    for j=1:length(tree_node_list)
      index=tree_node_list(j);
      if(i==1)
      tree_node(index).al=t_al(index);
      else
        l_id=tree_node(index).left_id;
        r_id=tree_node(index).right_id;
        l_al=tree_node(l_id).al;
        r_al=tree_node(r_id).al;
       if(tree_node(index).op==1) %and
         tree_node(index).al=min(l_al,r_al);
       else %or
         tree_node(index).al=max(l_al,r_al);  
       end
      end
    end
end

t_al_fin=tree_node(T_num).al;