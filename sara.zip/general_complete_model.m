%general model;
%23 07 2018

clear;

basic_threat_model;


%change price setting
price_base=[800 1000 2000 2000 2000];
price_add=[800 1000 2000 2000 2000];
%linear setting

for q_id=1:5
    for l_id=1:3
price_model(q_id,l_id)=price_base(q_id)+(l_id-1)*price_base(l_id);
    end
end

%change threat model

eq_list=cell(7);

eq_list{1}=1;
eq_list{2}=1;
eq_list{3}=1;
eq_list{4}=1;

eq_list{5}=2;

eq_list{6}=3;
eq_list{7}=3;

%basic setting

at_id=1;

id_list=1:7;

for t_id=id_list
t(at_id,eq_list{t_id},1,t_id)=1;
end

at_id=2:4;
for t_id=id_list
t(at_id,eq_list{t_id},1:2,t_id)=1;
end

at_id=5:6;
for t_id=id_list
t(at_id,eq_list{t_id},1:3,t_id)=1;
end

%
tree_model;

%

for (Alth=1:5)
[config,price_final,al_final,find_flag,rounds] = get_config_waterfill(t,AL,price_model,tree_node,Alth);
 find_list(Alth)=find_flag;
 price_list(Alth)=price_final;
 round_list(Alth)=rounds;
end

for (Alth=1:5)
[config,price_final,al_final,find_flag] = get_config_force(t,AL,price_model,tree_node,Alth);
 find_list_f(Alth)=find_flag;
 price_list_f(Alth)=price_final;
end