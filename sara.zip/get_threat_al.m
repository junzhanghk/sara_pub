function [t_al] = get_threat_al(config,t,AL)
%threat t(n,Q,L,T)
%equipment configuration config(Q)

[n Q L T]=size(t);

t_al=zeros(n,1);
temp_al=zeros(n,Q);

for i=1:T
  for j=1:Q
      list_a=find(t(:,j,config(j),i)==1);
      if(isempty(list_a)==1)
         temp_al(i,j)=0;
      else
         temp_al(i,j)=max(AL(list_a));
      end
  end
  t_al(i)=max(temp_al(i,:));
end