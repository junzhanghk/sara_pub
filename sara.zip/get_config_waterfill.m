function [config,price_final,al_final,find_flag,rounds] = get_config_waterfill(t,AL,price_model,tree_node,Alth)

%threat t
%AL at->AL
[n Q L T]=size(t);

T_num=length(tree_node);

T_lv=max([tree_node.lv]);


%find_flag

find_flag=0;

%min_cost
min_cost=1e10;

h=ones(Q,1)*L;

rounds=1;

price=get_price(h,price_model);
t_al = get_threat_al(h,t,AL);
[t_al_fin] = get_attack_al(t_al,tree_node);

if(t_al_fin>Alth)
 config=h;
 price_final=price;
 al_final=t_al_fin;
 find_flag=0;
 rounds=1;
 return;
end

find_flag=1;
h_current=h;
last_move=-1;

for i=1:L^Q-1
   h_temp={Q}; 
   for j=1:Q
     h_temp{j}=h_current;
     if(h_temp{j}(j)==1)
       t_al_fin_temp(j)=100;
     else
         
     h_temp{j}(j)=max(1,h_temp{j}(j)-1);
    
     price_temp(j)=get_price(h_temp{j},price_model);
     t_al = get_threat_al(h_temp{j},t,AL);
     [t_al_fin_temp(j)] = get_attack_al(t_al,tree_node);  
      rounds=rounds+1;   
     end
   end
    
   candidate_list=find(t_al_fin_temp<=Alth);
   if(isempty(candidate_list))
      break;
   end
   
   [value order]=min(price_temp(candidate_list));
   cur_value=value;
   cur_al=t_al_fin_temp(candidate_list(order));
   h_current=h_temp{candidate_list(order)};
   
   end

config=h_current;
price_final=cur_value;
al_final=cur_al;