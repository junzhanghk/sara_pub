%profile of relationship between attacker, equipment, 

%
eq_list=cell{7};

eq_list{1}=1;
eq_list{2}=1;
eq_list{3}=1;
eq_list{4}=1;

eq_list{5}=2;

eq_list{6}=3;
eq_list{7}=3;


%n=6;
%Q=5;
%L=3;
%T=7;
%init
t=zeros(n,Q,L,T);
%basic type
%left break right
% 1        1
% 2-4      2
% 5-6      3

at_id=1;

id_list=1:7;

for t_id=id_list
t(at_id,eq_list{t_id},1,t_id)=1;
end

at_id=2:4;
for t_id=id_list
t(at_id,eq_list{t_id},1:2,t_id)=1;
end

at_id=5:6;
for t_id=id_list
t(at_id,eq_list{t_id},1:3,t_id)=1;
end

%type shift 1

id_list=5:7

at_id=2:4;
for t_id=id_list
t(at_id,eq_list{t_id},1,t_id)=1;
end

at_id=5:6;
for t_id=id_list
t(at_id,eq_list{t_id},1:2,t_id)=1;
end

%type shift 2

id_list=7;


at_id=5:6;
for t_id=id_list
t(at_id,eq_list{t_id},1,t_id)=1;
end

%type undefencable attack

t_id=3:4;

t(:,:,:,t_id)=0;

at_id=1:6;
eq_id=1:3;

for t_id=3:4
t(at_id,eq_id,1:3,t_id)=1;
end


