%attack tree model
%23 july 2018

clear;

threat_model;

%tree node structure
%threat id: t_id
%up_node id: up_id
%down_left_id: left_id
%down_right_id: right_id
%operator :op  (0 no, 1 add, 2 or)
%aggregate al: al
%level:  lv

%tree node number

t_num=13;

%tree levels: 

T_lv=4;

%default setting
for i=1:t_num
  tree_node(i).t_id=0;
  tree_node(i).up_id=0;
  tree_node(i).left_id=0;
  tree_node(i).right_id=0;
  tree_node(i).op=0;
  tree_node(i).al=0;
  tree_node(i).lv=0;
end


%set leave nodes

for i=1:T
    tree_node(i).t_id=i;
    tree_node(i).al=0;
    tree_node(i).lv=1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
tree_node(8).left_id=1;
tree_node(8).right_id=2;
tree_node(8).op=2;
tree_node(8).lv=2;

tree_node(1).up_id=8;
tree_node(2).up_id=8;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tree_node(9).left_id=3;
tree_node(9).right_id=3;
tree_node(9).op=2;
tree_node(9).lv=2;

tree_node(3).up_id=8;
tree_node(4).up_id=8;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

tree_node(10).left_id=6;
tree_node(10).right_id=7;
tree_node(10).op=1;
tree_node(10).lv=2;

tree_node(6).up_id=10;
tree_node(7).up_id=10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55

tree_node(11).left_id=8;
tree_node(11).right_id=9;
tree_node(11).op=2;
tree_node(11).lv=3;

tree_node(8).up_id=11;
tree_node(9).up_id=11;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

tree_node(12).left_id=5;
tree_node(12).right_id=10;
tree_node(12).op=2;
tree_node(12).lv=3;

tree_node(5).up_id=12;
tree_node(10).up_id=12;

%%%%%%%%%%%%%%%%%%%%%%%%%%55
tree_node(13).left_id=11;
tree_node(13).right_id=12;
tree_node(13).op=1;
tree_node(13).lv=4;

tree_node(11).up_id=13;
tree_node(12).up_id=13;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for (Alth=1:5)
[config,price_final,al_final,find_flag,rounds] = get_config_waterfill(t,AL,price_model,tree_node,Alth);
 find_list(Alth)=find_flag;
 price_list(Alth)=price_final;
 round_list(Alth)=rounds;
end