%20,07,2018, threat model
%threat setting

%types of attackers
n=6;

%attack likelyhodd

al=5;

%levels of equipments
L=3;

%numbers of equipments

Q=5;

%price(Q,L);

price_model=zeros(Q,L);

price_model(1,1)=800;
price_model(1,2)=1600;
price_model(1,3)=2000;

price_model(2,1)=2000;
price_model(2,2)=2400;
price_model(2,3)=3000;

price_model(3,1)=1000;
price_model(3,2)=2000;
price_model(3,3)=3000;

%camera, v2x, external


%config(Q);

config=ones(Q,1);

%number of threats

T=7;

%threat combination
%1.Attack 2. Equipment id 3. Equipment level 

%Attack Likelyhood vector
AL=zeros(n,1);

%threat
t=zeros(n,Q,L,T);

Caa=[0 12 13 16 21 28];

ES=[0 1 4 10 17 19 1e4];
%Elasped time
%<1 day, <1 week,<1 month, <3 month, <6month, >6 month, not pratical inf
WO=[0 1 4 10 1e4];
%Window of Opportunity
%unnecssary, easy, moderate, difficult, none

%AP->AL
%0-9 basic 5
%10-13 enhanced basic 4
%14-19 moderate 3
%20-24 high 2
%>24 beyond high 1

%Attack potential
APa=Caa+ES(1)+WO(2);

for i=1:n
    if APa(i)<=9
        AL(i)=5;
    elseif APa(i)<=13
        AL(i)=4;
    elseif APa(i)<=19
        AL(i)=3;
    elseif APa(i)<=24
        AL(i)=2;
    else
        AL(i)=1;
    end
end

%t(n,Q,L,T);
%t(2,1,1,3): 1 if the threat 3 from attacker 2 for equipment 1 of level 1
%success

%threat 1: camera  switch off traffic light
%at:>=5
%eq:1
%defense level: 4


t(5,1,1:3,1)=1;
t(6,1,1:3,1)=1;

%threat 2: camera  blind camera
%at>=1
%eq:1
%defense level: 2

t(1:6,1,1,2)=1;



%threat 3: camera paint black color
%at>=1
%eq:1
%defense level: 4

t(1:6,1,1,3)=1;
t(1:6,1,2,3)=1;
t(1:6,1,3,3)=1;

%threat 4: camera, physical destruction of traffic light
%at>=1
%eq:1
%defense level: 4

t(1:6,1,1,4)=1;
t(1:6,1,2,4)=1;
t(1:6,1,3,4)=1;
%threat 5: v2x, alter v2x spat message (red->green)
%at>=2
%eq:2
%defense level: 2

t(2:6,2,1,5)=1;
%threat 6: externerl send faulty spat message
%at>=2
%eq:3
%defense level: 3

t(2:6,3,1,6)=1;
t(2:6,3,2,6)=1;

%threat 7: external change physical state cycle of traffic light
%at>=2
%eq:3
%defense level: 3

t(2:6,3,1,7)=1;
t(2:6,3,2,7)=1;


price=get_price(config,price_model);
t_al = get_threat_al(config,t,AL);