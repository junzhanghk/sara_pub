%files
%last update 23 07 2018
%n attacker
%Q equipment
%L levels
%T threats
%compute price
function [price] = get_price(config,price_model)

%get threat attack likelyhood
function [t_al] = get_threat_al(config,t,AL)

%get attack tree attack likelyhood
function [t_al_fin] = get_attack_al(t_al,tree_node)


%find config
%brute_force
function [config,price_final,al_final,find_flag] = get_config_force(t,AL,price_model,tree_node,Alth)
function [config,price_final,al_final,find_flag,rounds] = get_config_waterfill(t,AL,price_model,tree_node,Alth)

%

%config threat
threat_model.m

%config attack tree
attack_model.m
attack_model_with_config
attack_model_with_burte_force_search.m
attack_model_with_water_fill_search.m